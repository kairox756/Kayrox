import requests
import time
from colorama import Fore
from commands import config

# URL de tu servidor de validación
RELEASE_SERVER = "https://kayrox.qzz.io/api/release.json"

def release(shell, arg):
    "Solicita liberación con un código especial validado en servidor"
    shell.history.append(f"release {arg}")
    code = arg.strip()

    try:
        response = requests.get(RELEASE_SERVER, timeout=10)

        # Manejo seguro de respuesta
        try:
            data = response.json()
        except ValueError:
            print(Fore.RED + "El servidor no devolvió un JSON válido.")
            return

        # Buscar dentro de "codes"
        codes = data.get("codes", {})
        if code in codes:
            info = codes[code]
            if info.get("status") == "approved":
                wait_hours = info.get("wait_hours", 72)
                token = info.get("token")

                # Guardar estado pendiente en config.json
                shell.config["pending_release"] = True
                shell.config["release_start"] = int(time.time())
                shell.config["wait_hours"] = wait_hours
                shell.config["release_token"] = token
                config.save_config(shell.config)

                print(Fore.GREEN + f"Solicitud aprobada. Debes esperar {wait_hours} horas antes de liberar TermMik.")
            else:
                print(Fore.RED + "Código inválido o no autorizado.")
        else:
            print(Fore.RED + "El código no existe en el servidor.")

    except requests.RequestException as e:
        print(Fore.RED + f"Error al contactar servidor de liberación: {e}")

def check_release(shell):
    "Verifica si ya pasó el tiempo de espera y activa liberación"
    if shell.config.get("pending_release"):
        start = shell.config.get("release_start", 0)
        wait_hours = shell.config.get("wait_hours", 72)
        token = shell.config.get("release_token")

        elapsed_hours = (time.time() - start) / 3600
        if elapsed_hours >= wait_hours and token:
            shell.liberated = True
            shell.config["liberated"] = True
            shell.config["pending_release"] = False
            config.save_config(shell.config)
            print(Fore.YELLOW + "Liberación completada. TermMik ahora puede usar cualquier servidor.")
            print(Fore.RED + "⚠️ OTA deshabilitado en modo liberado.")
        else:
            faltan = int(wait_hours - elapsed_hours)
            print(Fore.CYAN + f"Aún faltan {faltan} horas para completar la liberación.")

def lock(shell, arg):
    "Bloquea TermMik nuevamente y restaura servidores oficiales"
    shell.history.append("lock")
    shell.liberated = False
    shell.config["liberated"] = False
    shell.config["pending_release"] = False
    shell.config["server_url"] = "https://kayrox.qzz.io/updates/kayrox_code_server_ChannelAlpha.json"
    shell.config["ota_url"] = "https://kayrox.qzz.io/updates/MikShellA.0.0.1.ATEMIALPH.json"
    config.save_config(shell.config)

    print(Fore.GREEN + "TermMik ha sido bloqueado nuevamente.")
    print(Fore.CYAN + "Modo normal: vinculado a servidores oficiales con soporte OTA.")