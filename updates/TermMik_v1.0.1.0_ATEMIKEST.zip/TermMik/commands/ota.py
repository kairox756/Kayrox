import requests, os, zipfile
from colorama import Fore

version_file = "version.txt"
ota_url = "https://kayrox.qzz.io/updates/MikShell.json"

def load_version():
    if os.path.exists(version_file):
        with open(version_file, "r") as f:
            return f.read().strip()
    return "1.0.1.0.ATEMIKEST"

def update(shell, arg):
    shell.history.append("update")
    try:
        print(Fore.CYAN + "Verificando actualizaciones OTA...")
        r = requests.get(ota_url, timeout=5)
        if r.status_code == 200:
            data = r.json()
            latest_version = data.get("latest", shell.current_version)
            download_url = data.get("download_url", None)
            release_date = data.get("release_date", "Desconocida")
            changelog = data.get("changelog", [])

            print(Fore.CYAN + f"Fecha de lanzamiento: {release_date}")
            print(Fore.CYAN + "Cambios:")
            for change in changelog:
                print(Fore.YELLOW + f" - {change}")

            if latest_version != shell.current_version and download_url:
                print(Fore.YELLOW + f"Nueva versión encontrada: {latest_version}")
                file_name = os.path.basename(download_url)
                response = requests.get(download_url, stream=True)
                with open(file_name, "wb") as f:
                    for chunk in response.iter_content(chunk_size=1024):
                        if chunk:
                            f.write(chunk)
                print(Fore.GREEN + f"Descarga completa: {file_name}")
                updates_dir = "updates"
                os.makedirs(updates_dir, exist_ok=True)
                with zipfile.ZipFile(file_name, "r") as zip_ref:
                    zip_ref.extractall(updates_dir)
                shell.current_version = latest_version
                with open(version_file, "w") as f:
                    f.write(shell.current_version)
                print(Fore.GREEN + f"Actualización instalada. Versión actual: {shell.current_version}")
            else:
                print(Fore.GREEN + f"Ya tienes la última versión instalada ({shell.current_version}).")
        else:
            print(Fore.RED + "No se pudo verificar actualizaciones. Error de servidor.")
    except Exception:
        print(Fore.RED + "No se pudo conectar al servidor OTA. Error: 0x00000678")
