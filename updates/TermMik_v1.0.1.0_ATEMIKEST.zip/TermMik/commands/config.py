import json
import os

CONFIG_FILE = "config.json"

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    else:
        return {
            "ota_url": "https://kayrox.qzz.io/updates/MikShellA.0.0.1.ATEMIALPH.json",
            "server_url": "https://kayrox.qzz.io/updates/kayrox_code_server_ChannelAlpha.json",
            "updates_dir": "updates",
            "color_theme": "cyan",
            "liberated": False
        }

def save_config(config_data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config_data, f, indent=4)