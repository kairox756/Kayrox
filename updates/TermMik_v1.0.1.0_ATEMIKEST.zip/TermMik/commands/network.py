import requests
import os
import socket
from colorama import Fore

def curl(shell, arg):
    "Descarga contenido de una URL"
    shell.history.append(f"curl {arg}")
    try:
        r = requests.get(arg, timeout=5)
        print(r.text[:500])  # muestra solo los primeros 500 caracteres
    except Exception as e:
        print(Fore.RED + f"Error: {e}")

def netinfo(shell, arg):
    "Muestra información de red"
    shell.history.append("netinfo")
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        print(Fore.CYAN + f"Hostname: {hostname}")
        print(Fore.CYAN + f"IP local: {local_ip}")
    except Exception as e:
        print(Fore.RED + f"Error: {e}")

def pinghost(shell, arg):
    "Hace ping a un host específico"
    shell.history.append(f"pinghost {arg}")
    try:
        response = os.system(f"ping -n 1 {arg}" if os.name == "nt" else f"ping -c 1 {arg}")
        if response == 0:
            print(Fore.GREEN + f"Conexión exitosa con {arg}")
        else:
            print(Fore.RED + f"No se pudo conectar con {arg}")
    except Exception as e:
        print(Fore.RED + f"Error: {e}")