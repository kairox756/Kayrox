import os
from colorama import Fore

def ls(shell, arg):
    "Lista archivos en el directorio actual"
    shell.history.append("ls")
    try:
        for item in os.listdir("."):
            print(item)
    except Exception as e:
        print(Fore.RED + f"Error: {e}")

def cd(shell, arg):
    "Cambia de directorio"
    shell.history.append(f"cd {arg}")
    try:
        os.chdir(arg)
        print(Fore.GREEN + f"Directorio cambiado a: {os.getcwd()}")
    except Exception as e:
        print(Fore.RED + f"Error: {e}")

def cat(shell, arg):
    "Muestra el contenido de un archivo"
    shell.history.append(f"cat {arg}")
    try:
        with open(arg, "r") as f:
            print(f.read())
    except Exception as e:
        print(Fore.RED + f"Error: {e}")

def rm(shell, arg):
    "Elimina un archivo"
    shell.history.append(f"rm {arg}")
    try:
        os.remove(arg)
        print(Fore.GREEN + f"Archivo eliminado: {arg}")
    except Exception as e:
        print(Fore.RED + f"Error: {e}")