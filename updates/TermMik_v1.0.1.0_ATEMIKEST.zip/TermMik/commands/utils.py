import os
import platform
from colorama import Fore
from datetime import datetime
from commands import config

def sysinfo(shell, arg):
    "Muestra información del sistema"
    shell.history.append("sysinfo")
    print(Fore.CYAN + f"Sistema: {platform.system()} {platform.release()}")
    print(Fore.CYAN + f"Python: {platform.python_version()}")
    print(Fore.CYAN + f"Hora actual: {datetime.now()}")

def clear(shell, arg):
    "Limpia la pantalla y vuelve a mostrar el intro"
    shell.history.append("clear")
    os.system("cls" if os.name == "nt" else "clear")
    print(shell.intro)

def echo(shell, arg):
    "Imprime el texto que escribas"
    shell.history.append(f"echo {arg}")
    print(arg)

def helpota(shell, arg):
    "Explica cómo funciona el sistema OTA"
    shell.history.append("helpota")
    print("El sistema OTA verifica el archivo JSON en el servidor.")
    print("Si la versión 'latest' es distinta a la instalada, descarga el .zip y lo instala en 'updates/'.")
    print("La versión actual se guarda en 'version.txt'.")

def history(shell, arg):
    "Muestra los últimos comandos ejecutados"
    print("Historial de comandos:")
    for cmd_item in shell.history:
        print(f" - {cmd_item}")

def alias(shell, arg):
    "Crea un alias para un comando. Ejemplo: alias ls=history"
    try:
        name, command = arg.split("=")
        shell.aliases[name.strip()] = command.strip()
        print(Fore.GREEN + f"Alias creado: {name.strip()} -> {command.strip()}")
    except Exception:
        print(Fore.RED + "Formato inválido. Usa: alias nombre=comando")

def default(shell, line):
    "Ejecuta alias si existe"
    if line in shell.aliases:
        shell.onecmd(shell.aliases[line])
    else:
        print(Fore.RED + f"Comando desconocido: {line}")

def set_config(shell, arg):
    "Modifica valores en config.json. Ejemplo: config server_url=https://nuevo.servidor.com"
    shell.history.append(f"config {arg}")
    try:
        key, value = arg.split("=", 1)
        key = key.strip()
        value = value.strip()
        shell.config[key] = value
        config.save_config(shell.config)
        print(Fore.GREEN + f"Configuración actualizada: {key} = {value}")
    except Exception as e:
        print(Fore.RED + f"Error al actualizar configuración: {e}")