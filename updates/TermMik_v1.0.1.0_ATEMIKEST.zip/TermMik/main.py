import cmd
from colorama import Fore, init
from commands import ota, files, network, utils, release, config

init(autoreset=True)

class TermMik(cmd.Cmd):
    intro = "Bienvenido a TermMik. Escribe 'help' o '?' para ver los comandos.\n"
    prompt = "TermMik> "

    def __init__(self):
        super().__init__()
        self.config = config.load_config()
        self.current_version = ota.load_version()
        self.history = []
        self.aliases = {}
        # Estado de liberación persistente
        self.liberated = self.config.get("liberated", False)

    # --- OTA ---
    def do_update(self, arg):
        if self.liberated:
            print(Fore.RED + f"Modo liberado: las actualizaciones OTA están deshabilitadas.")
        else:
            ota.update(self, arg)

    # --- Archivos ---
    def do_ls(self, arg): files.ls(self, arg)
    def do_cd(self, arg): files.cd(self, arg)
    def do_cat(self, arg): files.cat(self, arg)
    def do_rm(self, arg): files.rm(self, arg)

    # --- Red ---
    def do_curl(self, arg): network.curl(self, arg)
    def do_netinfo(self, arg): network.netinfo(self, arg)
    def do_pinghost(self, arg): network.pinghost(self, arg)

    # --- Utilidades ---
    def do_sysinfo(self, arg): utils.sysinfo(self, arg)
    def do_clear(self, arg): utils.clear(self, arg)
    def do_echo(self, arg): utils.echo(self, arg)
    def do_helpota(self, arg): utils.helpota(self, arg)
    def do_history(self, arg): utils.history(self, arg)
    def do_alias(self, arg): utils.alias(self, arg)
    def default(self, line): utils.default(self, line)
    def do_config(self, arg): utils.set_config(self, arg)

    # --- Liberación / Bloqueo ---
    def do_release(self, arg):
        release.release(self, arg)
        # Guardar estado en config.json
        self.config["liberated"] = self.liberated
        config.save_config(self.config)

    def do_lock(self, arg):
        release.lock(self, arg)
        # Guardar estado en config.json
        self.config["liberated"] = self.liberated
        config.save_config(self.config)

    # --- Salida ---
    def do_exit(self, arg):
        print("Cerrando TermMik...")
        return True

if __name__ == "__main__":
    TermMik().cmdloop()