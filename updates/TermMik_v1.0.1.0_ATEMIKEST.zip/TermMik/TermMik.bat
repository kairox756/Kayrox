@echo off
REM Lanzador de TermMik v1.0.1.0 ATEMIKEST
REM Asegúrate de tener Python 3.8 instalado y en PATH

setlocal
set PYTHON=python3.8

REM Cambiar al directorio donde está TermMik
cd /d "%~dp0"

REM Ejecutar main.py
%PYTHON% main.py

pause